import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://orsbyzrdzxlmeszmvdrz.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9yc2J5enJkenhsbWVzem12ZHJ6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEzMDE0MjksImV4cCI6MjA4Njg3NzQyOX0.xGij5tckI1c3AXLAf2NPHypUmIQc4rTm6pnSRH2ZPic',
  );
  runApp(const FitnessApp());
}

class FitnessApp extends StatelessWidget {
  const FitnessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fitness Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green, brightness: Brightness.light),
        useMaterial3: true,
      ),
      home: WorkoutListPage(),
    );
  }
}

// --- 1. หน้าแสดงข้อมูล (List Page) ---
class WorkoutListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Workouts 🏃‍♂️'),
        centerTitle: true,
        backgroundColor: Colors.green.shade100,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        // ดึงข้อมูลแบบ Real-time
        stream: Supabase.instance.client.from('workouts').stream(primaryKey: ['id']).order('created_at'),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          final workouts = snapshot.data!;
          if (workouts.isEmpty) return const Center(child: Text('ยังไม่มีข้อมูลการออกกำลังกาย'));

          return ListView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: workouts.length,
            itemBuilder: (context, index) {
              final item = workouts[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.fitness_center)),
                  title: Text(item['title'] ?? 'No Title', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${item['duration']} นาที | ระดับ: ${item['intensity']}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit, color: Colors.blue),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(
                      builder: (context) => EditWorkoutPage(workout: item),
                    )),
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const AddWorkoutPage())),
        label: const Text('เพิ่มบันทึก'),
        icon: const Icon(Icons.add),
      ),
    );
  }
}

// --- 2. หน้าเพิ่มข้อมูล (Add Page) ---
class AddWorkoutPage extends StatefulWidget {
  const AddWorkoutPage({super.key});
  @override
  State<AddWorkoutPage> createState() => _AddWorkoutPageState();
}

class _AddWorkoutPageState extends State<AddWorkoutPage> {
  final _titleController = TextEditingController();
  final _durationController = TextEditingController();
  String _intensity = 'Medium';

  Future<void> _saveWorkout() async {
    if (_titleController.text.isEmpty || _durationController.text.isEmpty) return;
    
    await Supabase.instance.client.from('workouts').insert({
      'title': _titleController.text,
      'duration': int.tryParse(_durationController.text) ?? 0,
      'intensity': _intensity,
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Workout')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'กิจกรรม (เช่น วิ่ง, เวท)')),
            TextField(controller: _durationController, decoration: const InputDecoration(labelText: 'ระยะเวลา (นาที)'), keyboardType: TextInputType.number),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _intensity,
              decoration: const InputDecoration(labelText: 'ความเหนื่อย'),
              items: ['Low', 'Medium', 'High'].map((val) => DropdownMenuItem(value: val, child: Text(val))).toList(),
              onChanged: (val) => setState(() => _intensity = val!),
            ),
            const SizedBox(height: 30),
            SUtilityButton(onPressed: _saveWorkout, text: 'บันทึกข้อมูล', color: Colors.green),
          ],
        ),
      ),
    );
  }
}

// --- 3. หน้าแก้ไขหรือลบข้อมูล (Edit / Delete Page) ---
class EditWorkoutPage extends StatefulWidget {
  final Map<String, dynamic> workout;
  const EditWorkoutPage({required this.workout});

  @override
  State<EditWorkoutPage> createState() => _EditWorkoutPageState();
}

class _EditWorkoutPageState extends State<EditWorkoutPage> {
  late TextEditingController _titleController;
  late TextEditingController _durationController;
  late String _intensity;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.workout['title']);
    _durationController = TextEditingController(text: widget.workout['duration'].toString());
    _intensity = widget.workout['intensity'] ?? 'Medium';
  }

  Future<void> _update() async {
    await Supabase.instance.client.from('workouts').update({
      'title': _titleController.text,
      'duration': int.tryParse(_durationController.text) ?? 0,
      'intensity': _intensity,
    }).match({'id': widget.workout['id']});
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    await Supabase.instance.client.from('workouts').delete().match({'id': widget.workout['id']});
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Workout'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red), 
            onPressed: () => _showDeleteDialog(),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _titleController, decoration: const InputDecoration(labelText: 'กิจกรรม')),
            TextField(controller: _durationController, decoration: const InputDecoration(labelText: 'ระยะเวลา (นาที)'), keyboardType: TextInputType.number),
            DropdownButtonFormField<String>(
              value: _intensity,
              decoration: const InputDecoration(labelText: 'ความเหนื่อย'),
              items: ['Low', 'Medium', 'High'].map((val) => DropdownMenuItem(value: val, child: Text(val))).toList(),
              onChanged: (val) => setState(() => _intensity = val!),
            ),
            const SizedBox(height: 30),
            SUtilityButton(onPressed: _update, text: 'อัปเดตข้อมูล', color: Colors.blue),
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ยืนยันการลบ?'),
        content: const Text('คุณต้องการลบรายการนี้ใช่หรือไม่?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ยกเลิก')),
          TextButton(onPressed: () { Navigator.pop(ctx); _delete(); }, child: const Text('ลบ', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
  }
}

// ปุ่ม Custom เพื่อความสวยงาม
class SUtilityButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final Color color;
  const SUtilityButton({required this.onPressed, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white),
        onPressed: onPressed,
        child: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }
}