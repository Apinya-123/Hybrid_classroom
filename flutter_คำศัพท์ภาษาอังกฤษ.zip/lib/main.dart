import 'package:flutter/material.dart';
import 'dart:math';

// ==========================================================
// 1. DATA MODEL (โครงสร้างข้อมูลคำศัพท์)
// ==========================================================
class Word {
  final String word;
  final String partOfSpeech;
  final String meaning;
  final String example;

  Word({
    required this.word,
    required this.partOfSpeech,
    required this.meaning,
    required this.example,
  });
}

// ==========================================================
// 2. MAIN APP STATE (ส่วนจัดการสถานะหลักของแอปฯ)
// ==========================================================

void main() {
  runApp(MaterialApp(
    title: 'แอปคำศัพท์',
    home: VocabularyApp(),
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
  ));
}

class VocabularyApp extends StatefulWidget {
  @override
  _VocabularyAppState createState() => _VocabularyAppState();
}

class _VocabularyAppState extends State<VocabularyApp> {
  int _selectedIndex = 0;
  
  // ฐานข้อมูลคำศัพท์เริ่มต้น (32 คำ)
  List<Word> vocabularyDatabase = [
    // คำศัพท์เดิม
    Word(word: "Serendipity", partOfSpeech: "Noun", meaning: "การค้นพบสิ่งที่ไม่คาดคิดแต่เป็นประโยชน์", example: "It was pure serendipity that I found my old wallet."),
    Word(word: "Ephemeral", partOfSpeech: "Adjective", meaning: "ไม่ยั่งยืน, ชั่วคราว", example: "The beauty of the flower is ephemeral."),

    // --- 30 คำศัพท์ใหม่ ---
    Word(word: "Ubiquitous", partOfSpeech: "Adjective", meaning: "มีอยู่ทั่วไปทุกหนทุกแห่ง", example: "Smartphones are ubiquitous now."),
    Word(word: "Nefarious", partOfSpeech: "Adjective", meaning: "ชั่วร้าย, โฉดชั่ว", example: "The nefarious villain planned to take over the world."),
    Word(word: "Ponder", partOfSpeech: "Verb", meaning: "ใคร่ครวญ, พิจารณาอย่างละเอียด", example: "She paused to ponder the consequences of her decision."),
    Word(word: "Elucidate", partOfSpeech: "Verb", meaning: "อธิบายให้ชัดเจน, ทำให้เข้าใจง่าย", example: "The professor elucidated the complex theory."),
    Word(word: "Mellifluous", partOfSpeech: "Adjective", meaning: "ไพเราะ, หวานหู (เสียง)", example: "The singer had a mellifluous voice."),
    Word(word: "Ineffable", partOfSpeech: "Adjective", meaning: "เกินกว่าจะบรรยาย, สุดจะพรรณนา", example: "The beauty of the sunrise was ineffable."),
    Word(word: "Trivial", partOfSpeech: "Adjective", meaning: "ไม่สำคัญ, เล็กน้อย", example: "We shouldn't argue over trivial matters."),
    Word(word: "Peculiar", partOfSpeech: "Adjective", meaning: "แปลก, ผิดปกติ", example: "He has a peculiar way of speaking."),
    Word(word: "Epitome", partOfSpeech: "Noun", meaning: "ตัวอย่างที่ดีที่สุด, แก่นสาร", example: "She is the epitome of elegance."),
    Word(word: "Voracious", partOfSpeech: "Adjective", meaning: "กระหาย, ตะกละ (โดยเฉพาะการอ่าน)", example: "He is a voracious reader of fantasy novels."),
    Word(word: "Resilient", partOfSpeech: "Adjective", meaning: "ยืดหยุ่น, ฟื้นตัวเร็ว", example: "The community proved incredibly resilient after the disaster."),
    Word(word: "Oblivion", partOfSpeech: "Noun", meaning: "การลืมเลือน, สภาวะที่ไม่รู้ตัว", example: "The old novel slipped into oblivion."),
    Word(word: "Scrutinize", partOfSpeech: "Verb", meaning: "พิจารณาอย่างถี่ถ้วน, ตรวจสอบ", example: "The police scrutinized the evidence."),
    Word(word: "Mitigate", partOfSpeech: "Verb", meaning: "บรรเทา, ลดความรุนแรง", example: "They needed to mitigate the risk of flooding."),
    Word(word: "Audacious", partOfSpeech: "Adjective", meaning: "กล้าหาญ, ไม่เกรงกลัว", example: "It was an audacious plan to climb the unclimbed peak."),
    Word(word: "Clairvoyant", partOfSpeech: "Adjective", meaning: "ตาทิพย์, มีญาณทิพย์", example: "The psychic claimed to be clairvoyant."),
    Word(word: "Disparate", partOfSpeech: "Adjective", meaning: "แตกต่างกันอย่างสิ้นเชิง", example: "The committee brought together disparate ideas."),
    Word(word: "Inherent", partOfSpeech: "Adjective", meaning: "ที่มีอยู่โดยธรรมชาติ, โดยเนื้อแท้", example: "The inherent danger of mountain climbing."),
    Word(word: "Lament", partOfSpeech: "Verb", meaning: "คร่ำครวญ, เศร้าโศก", example: "They lamented the loss of their cultural heritage."),
    Word(word: "Ostentatious", partOfSpeech: "Adjective", meaning: "โอ้อวด, หรูหราเกินความจำเป็น", example: "He drove an ostentatious sports car."),
    Word(word: "Pernicious", partOfSpeech: "Adjective", meaning: "เป็นอันตรายอย่างยิ่ง, ร้ายแรง", example: "The pernicious effects of pollution on health."),
    Word(word: "Redundant", partOfSpeech: "Adjective", meaning: "ซ้ำซ้อน, เหลือเฟือ", example: "Many workers were made redundant after the merger."),
    Word(word: "Sanctuary", partOfSpeech: "Noun", meaning: "ที่หลบภัย, เขตสงวน", example: "The wildlife sanctuary protects rare species."),
    Word(word: "Temperament", partOfSpeech: "Noun", meaning: "อารมณ์, ลักษณะนิสัย", example: "She has a calm and steady temperament."),
    Word(word: "Venerable", partOfSpeech: "Adjective", meaning: "น่านับถือ, น่าเคารพ", example: "The venerable monk gave a sermon."),
    Word(word: "Wanderlust", partOfSpeech: "Noun", meaning: "ความปรารถนาอย่างแรงกล้าที่จะท่องเที่ยว", example: "Her wanderlust led her to travel across Asia."),
    Word(word: "Zealous", partOfSpeech: "Adjective", meaning: "กระตือรือร้น, มุ่งมั่น", example: "He is a zealous supporter of environmental causes."),
    Word(word: "Juxtapose", partOfSpeech: "Verb", meaning: "วางเคียงกันเพื่อเปรียบเทียบ", example: "The artist juxtaposed bright colors with dark shades."),
    Word(word: "Nostalgia", partOfSpeech: "Noun", meaning: "ความคิดถึงบ้าน, ความโหยหาอดีต", example: "The old photos filled her with nostalgia."),
    Word(word: "Reticent", partOfSpeech: "Adjective", meaning: "เก็บตัว, ไม่ชอบพูด", example: "He was reticent about his past experiences."),
  ];

  // ฟังก์ชันเพิ่มคำศัพท์ (ส่งไปยัง AddWordScreen)
  void addWord(Word newWord) {
    setState(() {
      vocabularyDatabase.add(newWord);
      _selectedIndex = 2; // ย้ายไปหน้า List เมื่อเพิ่มเสร็จ
    });
  }

  // ฟังก์ชันสุ่มคำศัพท์ประจำวัน (ใช้ใน HomeScreen)
  Word? getRandomDailyWord() {
    if (vocabularyDatabase.isEmpty) return null;
    final random = Random();
    final randomIndex = random.nextInt(vocabularyDatabase.length);
    return vocabularyDatabase[randomIndex];
  }

  late final List<Widget> _widgetOptions = <Widget>[
    HomeScreen(getRandomDailyWord: getRandomDailyWord), // ส่งฟังก์ชันสุ่มคำ
    AddWordScreen(onAddWord: addWord),
    ListScreen(words: vocabularyDatabase),
    QuizScreen(words: vocabularyDatabase),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('แอปคำศัพท์ภาษาอังกฤษ'),
        backgroundColor: Colors.blueAccent,
      ),
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Add'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'List'),
          BottomNavigationBarItem(icon: Icon(Icons.help_outline), label: 'Quiz'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}

// ==========================================================
// 3. HOME SCREEN (ปรับปรุงการสุ่มคำศัพท์)
// ==========================================================

class HomeScreen extends StatelessWidget {
  // รับฟังก์ชันสุ่มคำศัพท์มาจาก State หลัก
  final Word? Function() getRandomDailyWord; 
  
  HomeScreen({required this.getRandomDailyWord});
  
  @override
  Widget build(BuildContext context) {
    // เรียกใช้ฟังก์ชันสุ่มคำศัพท์ทุกครั้งที่ Widget ถูกสร้างใหม่ (เมื่อเข้าหน้า)
    final dailyWord = getRandomDailyWord(); 
    
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: dailyWord == null 
        ? Text('ยังไม่มีคำศัพท์ในระบบ ลองเพิ่มคำศัพท์ใหม่', style: TextStyle(fontSize: 18))
        : Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('คำศัพท์ประจำวัน', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
            SizedBox(height: 10),
            Card(
              elevation: 4,
              child: ListTile(
                title: Text(dailyWord.word, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                subtitle: Text('(${dailyWord.partOfSpeech}) - ${dailyWord.meaning}', style: TextStyle(fontSize: 18)),
                trailing: Icon(Icons.star),
                isThreeLine: true,
                contentPadding: EdgeInsets.all(20),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Example: ${dailyWord.example}'),
            )
          ],
        ),
      ),
    );
  }
}

// ==========================================================
// 4. LIST SCREEN (หน้ารายการคำศัพท์ทั้งหมด)
// ==========================================================

class ListScreen extends StatelessWidget {
  final List<Word> words;
  ListScreen({required this.words});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: words.length,
      itemBuilder: (context, index) {
        final word = words[index];
        return Card(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          child: ListTile(
            title: Text(word.word, style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${word.meaning} (${word.partOfSpeech})'),
            trailing: Icon(Icons.chevron_right),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('ตัวอย่างประโยค: ${word.example}')),
              );
            },
          ),
        );
      },
    );
  }
}


// ==========================================================
// 5. ADD WORD SCREEN (หน้าจอเพิ่มคำศัพท์)
// ==========================================================

class AddWordScreen extends StatefulWidget {
  final Function(Word) onAddWord;

  AddWordScreen({required this.onAddWord});

  @override
  _AddWordScreenState createState() => _AddWordScreenState();
}

class _AddWordScreenState extends State<AddWordScreen> {
  final _wordController = TextEditingController();
  final _partOfSpeechController = TextEditingController();
  final _meaningController = TextEditingController();
  final _exampleController = TextEditingController();

  void _submitWord() {
    final word = _wordController.text.trim();
    final meaning = _meaningController.text.trim();

    if (word.isEmpty || meaning.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('กรุณาป้อน "คำศัพท์" และ "ความหมาย"')),
      );
      return;
    }

    final newWord = Word(
      word: word,
      partOfSpeech: _partOfSpeechController.text.trim().isEmpty ? "N/A" : _partOfSpeechController.text.trim(),
      meaning: meaning,
      example: _exampleController.text.trim().isEmpty ? "-" : _exampleController.text.trim(),
    );

    widget.onAddWord(newWord); 
    
    _wordController.clear();
    _partOfSpeechController.clear();
    _meaningController.clear();
    _exampleController.clear();
    
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('เพิ่มคำศัพท์ "${word}" สำเร็จ!')),
    );
  }

  @override
  void dispose() {
    _wordController.dispose();
    _partOfSpeechController.dispose();
    _meaningController.dispose();
    _exampleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text('กรอกข้อมูลคำศัพท์ใหม่', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 20),
          _buildTextField(_wordController, 'คำศัพท์ (Word)', required: true),
          _buildTextField(_partOfSpeechController, 'ชนิดของคำ (Part of Speech)', required: false),
          _buildTextField(_meaningController, 'ความหมาย (Meaning)', required: true),
          _buildTextField(_exampleController, 'ตัวอย่างประโยค (Example Sentence)', required: false, maxLines: 3),
          SizedBox(height: 30),
          ElevatedButton.icon(
            icon: Icon(Icons.save),
            label: Text('บันทึกคำศัพท์', style: TextStyle(fontSize: 18)),
            onPressed: _submitWord,
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 15),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildTextField(TextEditingController controller, String label, {required bool required, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: required ? '$label *' : label,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }
}


// ==========================================================
// 6. QUIZ SCREEN (หน้าจอทดสอบคำศัพท์)
// ==========================================================

class QuizScreen extends StatefulWidget {
  final List<Word> words;
  QuizScreen({required this.words});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _currentQuestionIndex = 0;
  int _score = 0;
  List<Map<String, dynamic>> _quizQuestions = [];
  bool _quizStarted = false;
  bool _quizFinished = false;

  @override
  void initState() {
    super.initState();
    if (widget.words.length >= 4) {
      _generateQuiz(5);
      _quizStarted = true;
    }
  }

  void _generateQuiz(int count) {
    if (widget.words.length < 4) return; 

    setState(() {
      _currentQuestionIndex = 0;
      _score = 0;
      _quizFinished = false;

      final shuffledWords = [...widget.words]..shuffle();
      final quizWords = shuffledWords.take(count).toList();

      _quizQuestions = quizWords.map((correctWord) {
        final incorrectWords = widget.words
            .where((word) => word.word != correctWord.word)
            .toList()
          ..shuffle();
        
        final allMeanings = [
          correctWord.meaning,
          ...incorrectWords.take(3).map((w) => w.meaning),
        ]..shuffle();

        return {
          'word': correctWord.word,
          'correctAnswer': correctWord.meaning,
          'options': allMeanings,
          'selectedAnswer': null,
          'isAnswered': false,
        };
      }).toList();
    });
  }

  void _answerQuestion(String selectedMeaning) {
    if (_quizQuestions[_currentQuestionIndex]['isAnswered'] == true) return;

    setState(() {
      _quizQuestions[_currentQuestionIndex]['selectedAnswer'] = selectedMeaning;
      _quizQuestions[_currentQuestionIndex]['isAnswered'] = true;

      final correctAnswer = _quizQuestions[_currentQuestionIndex]['correctAnswer'];
      if (selectedMeaning == correctAnswer) {
        _score++;
      }
    });
  }

  void _nextQuestion() {
    setState(() {
      if (_currentQuestionIndex < _quizQuestions.length - 1) {
        _currentQuestionIndex++;
      } else {
        _quizFinished = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.words.length < 4) {
      return Center(
        child: Text('ℹ️ ต้องมีคำศัพท์อย่างน้อย 4 คำเพื่อเริ่มทำ Quiz', style: TextStyle(fontSize: 18)),
      );
    }
    
    if (!_quizStarted) {
      return Center(child: CircularProgressIndicator()); 
    }

    if (_quizFinished) {
      return _buildResultScreen();
    }
    
    final currentQuestion = _quizQuestions[_currentQuestionIndex];
    final isAnswered = currentQuestion['isAnswered'] as bool;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'คำถามที่ ${_currentQuestionIndex + 1} / ${_quizQuestions.length}',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
          SizedBox(height: 10),
          Text(
            'คำศัพท์: "${currentQuestion['word']}" หมายถึงอะไร?',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          // ส่วนของตัวเลือก
          ... (currentQuestion['options'] as List<String>).map((option) {
            final isCorrect = option == currentQuestion['correctAnswer'];
            final isSelected = option == currentQuestion['selectedAnswer'];
            
            Color? tileColor;
            if (isAnswered) {
              if (isCorrect) {
                tileColor = Colors.green[100];
              } else if (isSelected) {
                tileColor = Colors.red[100];
              }
            }

            return Card(
              color: tileColor,
              child: ListTile(
                title: Text(option),
                onTap: isAnswered ? null : () => _answerQuestion(option),
                trailing: isAnswered
                    ? (isCorrect ? Icon(Icons.check, color: Colors.green) : (isSelected ? Icon(Icons.close, color: Colors.red) : null))
                    : null,
              ),
            );
          }).toList(),
          
          Spacer(),
          // ปุ่มถัดไป/เสร็จสิ้น
          if (isAnswered) 
            ElevatedButton(
              child: Text(
                _currentQuestionIndex < _quizQuestions.length - 1 ? 'คำถามถัดไป' : 'ดูผลลัพธ์',
                style: TextStyle(fontSize: 18),
              ),
              onPressed: _nextQuestion,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 15),
                backgroundColor: Colors.blueAccent
              ),
            ),
        ],
      ),
    );
  }
  
  // หน้าจอแสดงผลลัพธ์
  Widget _buildResultScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('🏆 การทดสอบเสร็จสิ้น! 🏆', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.green)),
            SizedBox(height: 20),
            Text(
              'คุณทำคะแนนได้',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              '$_score / ${_quizQuestions.length}',
              style: TextStyle(fontSize: 60, fontWeight: FontWeight.bold, color: Colors.blueAccent),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () => _generateQuiz(_quizQuestions.length),
              child: Text('ทำ Quiz ใหม่', style: TextStyle(fontSize: 18)),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}